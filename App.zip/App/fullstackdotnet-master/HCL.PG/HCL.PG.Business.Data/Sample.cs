﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCL.UBP.Business.Data
{
    public class Sample
    {
    }
}
