# fullstackdotnet
A POC on .NET 4.6.2 with MVC 5
